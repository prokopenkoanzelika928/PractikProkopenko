package com.example.mfcdocumentscheck;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        TextView title = findViewById(R.id.detailTitle);
        TextView fee = findViewById(R.id.detailFee);
        TextView term = findViewById(R.id.detailTerm);
        TextView documents = findViewById(R.id.detailDocuments);
        MaterialButton shareButton = findViewById(R.id.shareButton);
        Button backButton = findViewById(R.id.backButton);

        Intent intent = getIntent();

        String name = intent.getStringExtra("name");
        String feeText = intent.getStringExtra("fee");
        String termText = intent.getStringExtra("term");
        String docsText = intent.getStringExtra("documents");

        title.setText(name);
        fee.setText("Госпошлина: " + feeText);
        term.setText("Срок оказания: " + termText);
        documents.setText(docsText);

        shareButton.setOnClickListener(v -> {

            String shareText = "Услуга: " + name +
                    "\nГоспошлина: " + feeText +
                    "\nСрок: " + termText +
                    "\nДокументы:\n" + docsText;

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);

            startActivity(Intent.createChooser(shareIntent, "Поделиться через"));
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}