package com.example.mfcdocumentscheck;

import java.util.List;

public class Service {

    private String name;
    private List<String> requiredDocs;
    private List<String> optionalDocs;
    private String fee;
    private String term;
    private String documents;


    public Service(String name, String fee, String term, String documents) {
        this.name = name;
        this.fee = fee;
        this.term = term;
        this.documents = documents;
    }


    public String getName() { return name; }
    public List<String> getRequiredDocs() { return requiredDocs; }
    public List<String> getOptionalDocs() { return optionalDocs; }
    public String getFee() { return fee; }
    public String getTerm() { return term; }
    public String getDocuments() {
        return documents;
    }

}
