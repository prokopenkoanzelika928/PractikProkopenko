package com.example.mfcdocumentscheck;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import com.google.android.material.textfield.TextInputEditText;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static List<Service> services = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton btnSupport = findViewById(R.id.btnSupport);

        btnSupport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SupportActivity.class);
                startActivity(intent);
            }
        });

        services.add(new Service(
                "Получение паспорта",
                "300 руб.",
                "10 дней",
                "1. Заявление установленной формы\n" +
                        "2. Фото 3x4 (2 шт.)\n" +
                        "3. Свидетельство о рождении\n" +
                        "4. Военный билет (при наличии)"
        ));

        services.add(new Service(
                "Замена паспорта (по возрасту)",
                "300 руб.",
                "10 дней",
                "1. Старый паспорт\n" +
                        "2. Фото 3x4 (2 шт.)\n" +
                        "3. Заявление\n" +
                        "4. Свидетельство о браке (при наличии)"
        ));

        services.add(new Service(
                "Регистрация по месту жительства",
                "Бесплатно",
                "3 дня",
                "1. Паспорт\n" +
                        "2. Заявление\n" +
                        "3. Документ на жилое помещение\n" +
                        "4. Согласие собственника"
        ));

        services.add(new Service(
                "Снятие с регистрационного учёта",
                "Бесплатно",
                "3 дня",
                "1. Паспорт\n" +
                        "2. Заявление о снятии с регистрации"
        ));

        services.add(new Service(
                "Замена водительского удостоверения",
                "2000 руб.",
                "5 дней",
                "1. Паспорт\n" +
                        "2. Старое удостоверение\n" +
                        "3. Медицинская справка\n" +
                        "4. Квитанция об оплате"
        ));

        services.add(new Service(
                "Регистрация автомобиля",
                "1500 руб.",
                "1 день",
                "1. Паспорт\n" +
                        "2. ПТС\n" +
                        "3. Договор купли-продажи\n" +
                        "4. Полис ОСАГО"
        ));

        services.add(new Service(
                "Регистрация недвижимости",
                "500 руб.",
                "30 дней",
                "1. Паспорт\n" +
                        "2. Документы о праве собственности\n" +
                        "3. Кадастровый паспорт\n" +
                        "4. Согласие супруга (при наличии)"
        ));

        services.add(new Service(
                "Выписка из ЕГРН",
                "400 руб.",
                "5 дней",
                "1. Паспорт\n" +
                        "2. Заявление\n" +
                        "3. Кадастровый номер объекта"
        ));

        services.add(new Service(
                "Получение ИНН",
                "Бесплатно",
                "5 дней",
                "1. Паспорт\n" +
                        "2. Заявление установленной формы"
        ));

        services.add(new Service(
                "Получение СНИЛС",
                "Бесплатно",
                "5 дней",
                "1. Паспорт\n" +
                        "2. Заявление"
        ));

        services.add(new Service(
                "Оформление загранпаспорта",
                "5000 руб.",
                "30 дней",
                "1. Паспорт гражданина РФ\n" +
                        "2. Фото\n" +
                        "3. Заявление\n" +
                        "4. Военный билет (при наличии)\n" +
                        "5. Квитанция об оплате"
        ));

        services.add(new Service(
                "Регистрация брака",
                "350 руб.",
                "30 дней",
                "1. Паспорта обоих заявителей\n" +
                        "2. Совместное заявление\n" +
                        "3. Квитанция об оплате"
        ));

        services.add(new Service(
                "Расторжение брака",
                "650 руб.",
                "30 дней",
                "1. Паспорт\n" +
                        "2. Свидетельство о браке\n" +
                        "3. Заявление\n" +
                        "4. Решение суда (если требуется)"
        ));

        services.add(new Service(
                "Получение справки о составе семьи",
                "Бесплатно",
                "1 день",
                "1. Паспорт\n" +
                        "2. Заявление"
        ));

        services.add(new Service(
                "Замена фамилии",
                "1600 руб.",
                "30 дней",
                "1. Паспорт\n" +
                        "2. Свидетельство о рождении\n" +
                        "3. Заявление\n" +
                        "4. Свидетельство о браке (при наличии)\n" +
                        "5. Квитанция об оплате"
        ));


        TextInputEditText searchInput = findViewById(R.id.searchInput);

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new ServiceAdapter(this, services));
    }

    private void filter(String text) {
        List<Service> filtered = new ArrayList<>();
        for (Service s : services) {
            if (s.getName().toLowerCase().contains(text.toLowerCase())) {
                filtered.add(s);
            }
        }

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setAdapter(new ServiceAdapter(this, filtered));
    }

}