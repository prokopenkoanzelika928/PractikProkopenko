package com.example.mfcdocumentscheck;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class SupportActivity extends AppCompatActivity {

    private RecyclerView chatRecyclerView;
    private TextInputEditText messageEditText;
    private MaterialButton sendButton;
    private Button hintDocsList, hintStatus, hintHotline, hintOther;

    private ArrayList<String> messages = new ArrayList<>();
    private ChatAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);

        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);
        hintDocsList = findViewById(R.id.hintDocsList);
        hintStatus = findViewById(R.id.hintStatus);
        hintHotline = findViewById(R.id.hintHotline);
        hintOther = findViewById(R.id.hintOther);

        adapter = new ChatAdapter(messages);
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatRecyclerView.setAdapter(adapter);

        sendButton.setOnClickListener(v -> sendMessage(messageEditText.getText().toString()));

        hintDocsList.setOnClickListener(v -> sendMessage("Какие документы нужны"));
        hintStatus.setOnClickListener(v -> sendMessage("Статус заявки"));
        hintHotline.setOnClickListener(v -> sendMessage("Горячая линия"));
        hintOther.setOnClickListener(v -> sendMessage("Другое"));
    }

    private void sendMessage(String msg) {
        if (TextUtils.isEmpty(msg)) return;

        messages.add("Вы: " + msg);
        messages.add("Система: " + generateSystemReply(msg));

        adapter.notifyDataSetChanged();
        chatRecyclerView.scrollToPosition(messages.size() - 1);
        messageEditText.setText("");
    }

    private String generateSystemReply(String userMessage) {
        userMessage = userMessage.toLowerCase();

        if (userMessage.contains("как зайти") || userMessage.contains("вход")) {
            return "Для входа используйте логин и пароль. Если забыли пароль — нажмите 'Забыли пароль?' на экране входа.";
        } else if (userMessage.contains("какие документы") || userMessage.contains("документ")) {
            return "Список документов зависит от услуги. Обычно требуется паспорт, заявление и квитанция об оплате (если нужно).";
        } else if (userMessage.contains("получить документ")) {
            return "Чтобы получить документ, выберите услугу и подайте заявление. Некоторые услуги требуют личного посещения.";
        } else if (userMessage.contains("статус")) {
            return "Статус заявки можно проверить в разделе 'Мои заявки' или по номеру заявления.";
        } else if (userMessage.contains("горячая линия") || userMessage.contains("телефон")) {
            return "Телефон горячей линии: 8-800-100-00-00. Звонок бесплатный.";
        } else if (userMessage.contains("другое")) {
            return "Пожалуйста, уточните ваш вопрос более подробно.";
        } else {
            return "Извините, я не понимаю ваш запрос. Попробуйте воспользоваться подсказками выше.";
        }
    }

    private static class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

        private ArrayList<String> messages;

        ChatAdapter(ArrayList<String> messages) {
            this.messages = messages;
        }

        @Override
        public ChatViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_message, parent, false);
            return new ChatViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ChatViewHolder holder, int position) {
            String msg = messages.get(position);

            if (msg.startsWith("Система:")) {
                holder.systemIcon.setVisibility(View.VISIBLE);
                holder.messageText.setText(msg.replace("Система: ", ""));
            } else {
                holder.systemIcon.setVisibility(View.GONE);
                holder.messageText.setText(msg.replace("Вы: ", ""));
            }
        }

        @Override
        public int getItemCount() {
            return messages.size();
        }

        static class ChatViewHolder extends RecyclerView.ViewHolder {
            TextView messageText;
            ImageView systemIcon;

            ChatViewHolder(View itemView) {
                super(itemView);
                messageText = itemView.findViewById(R.id.messageText);
                systemIcon = itemView.findViewById(R.id.systemIcon);
            }
        }
    }
}
