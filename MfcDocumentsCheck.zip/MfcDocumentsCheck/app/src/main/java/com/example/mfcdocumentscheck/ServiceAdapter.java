package com.example.mfcdocumentscheck;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ServiceAdapter extends RecyclerView.Adapter<ServiceAdapter.ViewHolder> {

    private List<Service> serviceList;
    private Context context;

    public ServiceAdapter(Context context, List<Service> serviceList) {
        this.context = context;
        this.serviceList = serviceList;
    }

    @NonNull
    @Override
    public ServiceAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_service, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Service service = serviceList.get(position);

        holder.name.setText(service.getName());
        holder.info.setText("Госпошлина: " + service.getFee()
                + " | Срок: " + service.getTerm());

        holder.itemView.setOnClickListener(v -> {

            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("name", service.getName());
            intent.putExtra("fee", service.getFee());
            intent.putExtra("term", service.getTerm());
            intent.putExtra("documents", service.getDocuments());

            context.startActivity(intent);
        });

    }


    @Override
    public int getItemCount() {
        return serviceList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, info;

        public ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.serviceName);
            info = itemView.findViewById(R.id.serviceInfo);
        }

    }
}